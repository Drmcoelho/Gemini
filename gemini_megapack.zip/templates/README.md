# Templates de Prompt (exemplos)

- **rx**: Condutas estruturadas incluindo itens obrigatórios (apresentação, diluição, etc.).
- **brief**: Resumo em 5 bullets conclusivos.
- **sgarbossa**: Critérios práticos para BRE/MP.
- **hda**: Fluxo de HDA do primeiro atendimento à estabilização.

Edite `~/.config/gemx/config.json` para personalizar.
